package night.modules.impl.movement;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.inventory.AnvilScreen;
import net.minecraft.client.gui.screens.inventory.BookEditScreen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.client.gui.screens.inventory.JigsawBlockEditScreen;
import net.minecraft.client.gui.screens.inventory.SignEditScreen;
import net.minecraft.client.gui.screens.inventory.StructureBlockEditScreen;
import net.minecraft.world.item.CreativeModeTab.Type;
import night.events.SubscribeEvent;
import night.events.impl.TickEvent;
import night.mixins.accessors.CreativeInventoryScreenAccessor;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BooleanSetting;
import night.utils.minecraft.GrimV3Inventory;

@RegisterModule(
   name = "InventoryControl",
   description = "Allows you to control things such as movement and your camera while a GUI is open.",
   category = Module.Category.MOVEMENT
)
public class InventoryControlModule extends Module {
   public BooleanSetting movement = new BooleanSetting("Movement", "Allows you to control movement.", true);
   public BooleanSetting portals = new BooleanSetting("Portals", "Allows you to interact with GUIs while inside of a portal.", true);
   public BooleanSetting dragClick = new BooleanSetting("DragClick", "Hold shift + left-click and drag over slots to move each item you pass over.", true);
   public BooleanSetting grimV3 = new BooleanSetting(
      "GrimV3", "Coordinate routine inventory work while stationary in safe Phase cover; uses a real inventory screen.", false
   );
   public BooleanSetting grimV2 = new BooleanSetting("GrimV2", "Bypasses inventory-while-moving checks on GrimV2/NCP servers.", false);

   @Override
   public void onDisable() {
      GrimV3Inventory.cancel();
   }

   @SubscribeEvent
   public void onTick(TickEvent event) {
      GrimV3Inventory.tick();
      if (GrimV3Inventory.holdMovement()) {
         GrimV3Inventory.stopKeys();
      } else if (mc.player != null) {
         if (this.movement.getValue()
            && mc.gui.screen() != null
            && !(mc.gui.screen() instanceof ChatScreen)
            && !(mc.gui.screen() instanceof BookEditScreen)
            && !(mc.gui.screen() instanceof SignEditScreen)
            && !(mc.gui.screen() instanceof JigsawBlockEditScreen)
            && !(mc.gui.screen() instanceof StructureBlockEditScreen)
            && !(mc.gui.screen() instanceof AnvilScreen)
            && (!(mc.gui.screen() instanceof CreativeModeInventoryScreen) || CreativeInventoryScreenAccessor.getSelectedTab().getType() != Type.SEARCH)) {
            for (KeyMapping binding : new KeyMapping[]{
               mc.options.keyUp, mc.options.keyDown, mc.options.keyRight, mc.options.keyLeft, mc.options.keySprint, mc.options.keyShift, mc.options.keyJump
            }) {
               binding.setDown(InputConstants.isKeyDown(mc.getWindow(), InputConstants.getKey(binding.saveString()).getValue()));
            }
         }
      }
   }
}
