package night.modules.impl.player;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import night.Night;
import night.events.SubscribeEvent;
import night.events.impl.ClientDisconnectEvent;
import night.events.impl.PlayerDeathEvent;
import night.events.impl.PlayerPopEvent;
import night.events.impl.PlayerUpdateEvent;
import night.events.impl.TickEvent;
import night.modules.Module;
import night.modules.RegisterModule;
import night.settings.impl.BindSetting;
import night.settings.impl.BooleanSetting;
import night.settings.impl.CategorySetting;
import night.settings.impl.ModeSetting;
import night.settings.impl.NumberSetting;
import night.utils.minecraft.AutoShopLifecycle;
import night.utils.minecraft.GrimV3Inventory;
import night.utils.minecraft.InventoryUtils;
import night.utils.minecraft.KitRestockMath;
import night.utils.minecraft.ManualMainhandFood;

@RegisterModule(
   name = "AutoShop",
   description = "Automates the server /shop GUI to buy totems, end crystals, or exp bottles.",
   category = Module.Category.KINGMC,
   persistent = true
)
public class AutoShopModule extends Module {
   public CategorySetting totemCategory = new CategorySetting("Totem", "Automatic Totem restock and manual purchase settings.");
   public BooleanSetting totemBelowThreshold = new BooleanSetting(
      "TotemBelowThreshold",
      "Enabled",
      "Automatically buy Totems after the configured number are lost.",
      new CategorySetting.Visibility(this.totemCategory),
      true
   );
   public BindSetting totem = new BindSetting("Totem", "Bind", "Keybind to auto buy totems.", new CategorySetting.Visibility(this.totemCategory), 0)
      .disableHoldModes();
   public NumberSetting totemAmount = new NumberSetting(
      "TotemAmount", "Amount", "How many totems to buy.", new CategorySetting.Visibility(this.totemCategory), 1, 1, 10
   );
   public NumberSetting totemLostCount = new NumberSetting(
      "TotemLostCount", "Lost Totems", "Totems lost before one automatic purchase.", new CategorySetting.Visibility(this.totemCategory), 2, 1, 64
   );
   public CategorySetting crystalCategory = new CategorySetting("Crystal", "Automatic Crystal restock and manual purchase settings.");
   public BooleanSetting crystalBelowThreshold = new BooleanSetting(
      "CrystalBelowThreshold",
      "Enabled",
      "Buy one Crystal order when stock reaches the threshold.",
      new CategorySetting.Visibility(this.crystalCategory),
      false
   );
   public BindSetting crystal = new BindSetting("Crystal", "Bind", "Keybind to auto buy end crystals.", new CategorySetting.Visibility(this.crystalCategory), 0)
      .disableHoldModes();
   public NumberSetting crystalStacks = new NumberSetting(
      "CrystalStacks", "Stacks", "How many stacks (64) of end crystals to buy.", new CategorySetting.Visibility(this.crystalCategory), 1, 1, 10
   );
   public NumberSetting crystalThreshold = new NumberSetting(
      "CrystalThreshold", "Threshold", "Crystal stack threshold.", new CategorySetting.Visibility(this.crystalCategory), 1, 0, 20
   );
   public CategorySetting expCategory = new CategorySetting("Exp", "Automatic Exp restock and manual purchase settings.");
   public BooleanSetting expBelowThreshold = new BooleanSetting(
      "ExpBelowThreshold", "Enabled", "Buy one Exp order when stock reaches the threshold.", new CategorySetting.Visibility(this.expCategory), false
   );
   public BindSetting exp = new BindSetting("Exp", "Bind", "Keybind to auto buy exp bottles.", new CategorySetting.Visibility(this.expCategory), 0)
      .disableHoldModes();
   public NumberSetting expStacks = new NumberSetting(
      "ExpStacks", "Stacks", "How many stacks (64) of exp bottles to buy.", new CategorySetting.Visibility(this.expCategory), 1, 1, 10
   );
   public NumberSetting expThreshold = new NumberSetting(
      "ExpThreshold", "Threshold", "Exp stack threshold.", new CategorySetting.Visibility(this.expCategory), 1, 0, 20
   );
   public CategorySetting obsidianCategory = new CategorySetting("Obsidian", "Automatic Obsidian restock and manual purchase settings.");
   public BooleanSetting obsidianBelowThreshold = new BooleanSetting(
      "ObsidianBelowThreshold",
      "Enabled",
      "Buy one Obsidian order when stock reaches the threshold.",
      new CategorySetting.Visibility(this.obsidianCategory),
      false
   );
   public BindSetting obsidian = new BindSetting("Obsidian", "Bind", "Keybind to auto buy obsidian.", new CategorySetting.Visibility(this.obsidianCategory), 0)
      .disableHoldModes();
   public NumberSetting obsidianStacks = new NumberSetting(
      "ObsidianStacks", "Stacks", "How many stacks (64) of obsidian to buy.", new CategorySetting.Visibility(this.obsidianCategory), 1, 1, 10
   );
   public NumberSetting obsidianThreshold = new NumberSetting(
      "ObsidianThreshold", "Threshold", "Obsidian stack threshold.", new CategorySetting.Visibility(this.obsidianCategory), 1, 0, 20
   );
   public CategorySetting enderPearlCategory = new CategorySetting("EnderPearl", "Automatic EnderPearl restock and manual purchase settings.");
   public BooleanSetting enderPearlBelowThreshold = new BooleanSetting(
      "EnderPearlBelowThreshold",
      "Enabled",
      "Buy one EnderPearl order when stock reaches the threshold.",
      new CategorySetting.Visibility(this.enderPearlCategory),
      false
   );
   public BindSetting enderPearl = new BindSetting(
         "EnderPearl", "Bind", "Keybind to auto buy ender pearls.", new CategorySetting.Visibility(this.enderPearlCategory), 0
      )
      .disableHoldModes();
   public NumberSetting enderPearlStacks = new NumberSetting(
      "EnderPearlStacks", "Stacks", "How many stacks (64) of ender pearls to buy.", new CategorySetting.Visibility(this.enderPearlCategory), 1, 1, 10
   );
   public NumberSetting enderPearlThreshold = new NumberSetting(
      "EnderPearlThreshold", "Threshold", "EnderPearl stack threshold.", new CategorySetting.Visibility(this.enderPearlCategory), 1, 0, 20
   );
   public ModeSetting restockMode = new ModeSetting(
      "RestockMode", "KitPercent fills the saved kit; Existing uses the original stack thresholds.", "KitPercent", new String[]{"KitPercent", "Existing"}
   );
   public NumberSetting kitThresholdPercent = new NumberSetting("KitThresholdPercent", "Start restocking at this percent of the saved kit amount.", 50, 1, 95);
   public NumberSetting kitRetryDelay = new NumberSetting(
      "KitRetryDelay", "Seconds before retrying a failed automatic order, 0-30 seconds. Does not pace successful purchase clicks.", 5, 0, 30
   );
   public BooleanSetting silent = new BooleanSetting("Silent", "Suppress expected real shop screens before presentation.", false);
   public NumberSetting actionDelay = new NumberSetting("ActionDelay", "Ticks between each shop GUI click.", 4, 0, 20);
   private static final int SLOT_ITEM_TOTEM = 13;
   private static final int SLOT_ITEM_CRYSTAL = 10;
   private static final int SLOT_ITEM_EXP = 16;
   private static final int SLOT_ITEM_OBSIDIAN = 9;
   private static final int SLOT_ITEM_ENDERPEARL = 14;
   private static final int SLOT_SET_1 = 15;
   private static final int SLOT_SET_11 = 16;
   private static final int SLOT_CONFIRM = 23;
   private static final int STEP_TIMEOUT_TICKS = 100;
   private AutoShopModule.State state = AutoShopModule.State.IDLE;
   private final Queue<AutoShopModule.PurchaseOrder> orderQueue = new ConcurrentLinkedQueue<>();
   private AutoShopModule.PurchaseOrder currentOrder = null;
   private int ticks = 0;
   private int timeoutTicks = 0;
   private boolean quantitySet = false;
   private final AutoShopModule.AutoControl[] autoControls = new AutoShopModule.AutoControl[]{
      new AutoShopModule.AutoControl(),
      new AutoShopModule.AutoControl(),
      new AutoShopModule.AutoControl(),
      new AutoShopModule.AutoControl(),
      new AutoShopModule.AutoControl()
   };
   private int totemPopsSincePurchase;
   private Object lastRestockKit;
   private String lastRestockMode;
   private final long[] lastAutoDiagnosticMs = new long[5];
   private Object lastWorld;
   private Object lastPlayer;
   private long generation;
   private long expectedGeneration;
   private AutoShopModule.ResponseReason expectedReason = AutoShopModule.ResponseReason.NONE;
   private long expectationExpiresAt;
   private boolean realShopScreenIntercepted;
   private boolean silentSession;
   private long nextKitOrderAt;
   private long lastDiagnosticCommandAt;
   private boolean totemTrackingInitialized;
   private boolean totemContainerResyncPending;
   private boolean totemZeroFailsafePending;
   private boolean totemZeroFailsafeUsed;
   private boolean totemOrderRecovered;
   private String totemEpisodeTriggerReason;
   private int baselineTotems;
   private int previousObservedTotems;

   private void diagnoseAuto(AutoShopModule.ShopMode mode, boolean enabled, int stock, AutoShopModule.AutoControl control) {
      KeyActionModule key = Night.MODULE_MANAGER.getModule(KeyActionModule.class);
      if (key != null && key.botXpDebug.getValue()) {
         long now = System.currentTimeMillis();
         if (now - this.lastAutoDiagnosticMs[mode.ordinal()] >= 2000L) {
            this.lastAutoDiagnosticMs[mode.ordinal()] = now;
            Night.LOGGER
               .info(
                  "[ShopAutoDiag] player={} mode={} enabled={} stock={} threshold={} kitQuota={} kitTarget={} capacity={} phase={} state={} queued={} space={} screen={} container={}",
                  new Object[]{
                     mc.player.getName().getString(),
                     mode,
                     enabled,
                     stock,
                     this.thresholdCount(mode, itemFor(mode)),
                     this.usesKitQuota(),
                     this.kitTarget(itemFor(mode)),
                     this.kitCapacity(itemFor(mode)),
                     control.phase,
                     this.state,
                     this.orderQueue.size(),
                     this.autoStartSafe(itemFor(mode)),
                     mc.gui.screen() != null,
                     mc.player.hasContainerOpen()
                  }
               );
         }
      }
   }

   public AutoShopModule() {
      this.bind.disableHoldModes();
      this.restockMode.getVisibility().setVisible(false);
      this.kitThresholdPercent.getVisibility().setVisible(false);
   }

   public void handleKey(int key) {
      if (!AutoShopLifecycle.guard(this)) {
         if (this.isToggled() && key != 0) {
            if (this.totem.getValue() != 0 && key == this.totem.getValue()) {
               this.enqueueOrder(AutoShopModule.ShopMode.Totem, this.totemAmount.getValue().intValue());
            } else if (this.crystal.getValue() != 0 && key == this.crystal.getValue()) {
               this.enqueueOrder(AutoShopModule.ShopMode.Crystal, this.crystalStacks.getValue().intValue());
            } else if (this.exp.getValue() != 0 && key == this.exp.getValue()) {
               this.enqueueOrder(AutoShopModule.ShopMode.Exp, this.expStacks.getValue().intValue());
            } else if (this.obsidian.getValue() != 0 && key == this.obsidian.getValue()) {
               this.enqueueOrder(AutoShopModule.ShopMode.Obsidian, this.obsidianStacks.getValue().intValue());
            } else if (this.enderPearl.getValue() != 0 && key == this.enderPearl.getValue()) {
               this.enqueueOrder(AutoShopModule.ShopMode.EnderPearl, this.enderPearlStacks.getValue().intValue());
            }
         }
      }
   }

   public synchronized void enqueueOrder(AutoShopModule.ShopMode shopMode, int amount) {
      Night.LOGGER.info("[AutoShop] MANUAL_REQUEST mode={} amount={}", shopMode, amount);
      this.enqueuePurchaseOrder(new AutoShopModule.PurchaseOrder(shopMode, amount));
   }

   private synchronized void enqueuePurchaseOrder(AutoShopModule.PurchaseOrder order) {
      if (!AutoShopLifecycle.guard(this)) {
         if (this.isToggled() && mc.player != null && mc.getConnection() != null) {
            if (order.remaining > 0) {
               this.orderQueue.add(order);
               if (this.state == AutoShopModule.State.IDLE && this.canBeginOrder()) {
                  this.currentOrder = this.orderQueue.poll();
                  this.beginOrder();
               }
            }
         }
      }
   }

   private boolean canBeginOrder() {
      return ManualMainhandFood.active()
         ? false
         : mc.player != null && !GrimV3Inventory.busy() && mc.player.containerMenu.getCarried().isEmpty() && !InventoryUtils.hasActiveSilentSwitch();
   }

   private void beginOrder() {
      GrimV3Inventory.cancel();
      InventorySorterModule sorter = Night.MODULE_MANAGER.getModule(InventorySorterModule.class);
      if (sorter != null) {
         sorter.invalidateSort();
      }

      ThrowItemModule thrower = Night.MODULE_MANAGER.getModule(ThrowItemModule.class);
      if (thrower != null) {
         thrower.invalidateCleanup();
      }

      this.generation++;
      this.clearSilentState();
      this.lastWorld = mc.level;
      this.lastPlayer = mc.player;
      this.ticks = 0;
      this.timeoutTicks = 0;
      this.quantitySet = this.currentOrder != null && this.currentOrder.kitTarget > 0 && this.currentOrder.quantity == 1;
      this.state = AutoShopModule.State.WAIT_SHOP;
      this.sendShopCommand();
   }

   private void sendShopCommand() {
      if (mc.getConnection() != null) {
         long commandNow = System.currentTimeMillis();
         KeyActionModule key = Night.MODULE_MANAGER.getModule(KeyActionModule.class);
         if (key != null && key.botXpDebug.getValue() && mc.player != null) {
            Night.LOGGER
               .info(
                  "[BotShop] command gapMs={} state={} xp={} container={} selected={} serverSlot={} main={} off={}",
                  new Object[]{
                     this.lastDiagnosticCommandAt == 0L ? 0L : commandNow - this.lastDiagnosticCommandAt,
                     this.state,
                     key.isXpActive(),
                     mc.player.containerMenu.containerId,
                     mc.player.getInventory().getSelectedSlot(),
                     Night.POSITION_MANAGER.getServerSlot(),
                     mc.player.getMainHandItem(),
                     mc.player.getOffhandItem()
                  }
               );
         }

         this.lastDiagnosticCommandAt = commandNow;
         this.armExpectedResponse(AutoShopModule.ResponseReason.SHOP_COMMAND);
         Night.LOGGER
            .info(
               "[AutoShop] SHOP_COMMAND source={} mode={}",
               this.currentOrder == null ? "unknown" : this.currentOrder.origin,
               this.currentOrder == null ? "unknown" : this.currentOrder.mode
            );
         mc.getConnection().sendCommand("shop open gear");
      }
   }

   public synchronized AutoShopModule.ScreenDecision classifyScreen(Screen screen) {
      if (this.state == AutoShopModule.State.IDLE
         || !this.silent.getValue()
         || !(this.currentOrder != null && screen instanceof AbstractContainerScreen<?> containerScreen)
         || screen instanceof InventoryScreen) {
         return AutoShopModule.ScreenDecision.PASS;
      } else if (mc.player != null
         && mc.player.containerMenu != null
         && mc.player.containerMenu != mc.player.inventoryMenu
         && containerScreen.getMenu() == mc.player.containerMenu
         && mc.gui.screen() == null) {
         this.expireExpectedResponse();
         if (this.expectedReason != AutoShopModule.ResponseReason.NONE && this.expectedGeneration == this.generation) {
            AutoShopModule.ResponseReason reason = this.expectedReason;
            Night.LOGGER
               .info(
                  "[AutoShop] SHOP_SCREEN_INTERCEPT state={} reason={} generation={} containerId={} screenClass={}",
                  new Object[]{this.state, reason, this.generation, mc.player.containerMenu.containerId, screen.getClass().getSimpleName()}
               );
            if (reason == AutoShopModule.ResponseReason.SHOP_COMMAND) {
               this.realShopScreenIntercepted = true;
            }

            this.silentSession = true;
            this.expectedReason = AutoShopModule.ResponseReason.NONE;
            Night.LOGGER.info("[AutoShop] SILENT_SUPPRESS generation={} containerId={}", this.generation, mc.player.containerMenu.containerId);
            return AutoShopModule.ScreenDecision.SUPPRESS_EXPECTED;
         } else {
            this.resetTransactionWithoutClosingContainer("No valid expected shop response");
            return AutoShopModule.ScreenDecision.FAIL_OPEN_UNEXPECTED;
         }
      } else {
         this.resetTransactionWithoutClosingContainer("Unexpected container structure");
         return AutoShopModule.ScreenDecision.FAIL_OPEN_UNEXPECTED;
      }
   }

   private void armExpectedResponse(AutoShopModule.ResponseReason reason) {
      if (this.silent.getValue() && this.currentOrder != null) {
         this.expectedReason = reason;
         this.expectedGeneration = this.generation;
         this.expectationExpiresAt = System.nanoTime() + 2000000000L;
         Night.LOGGER.info("[AutoShop] SILENT_EXPECT reason={} generation={} mode={}", new Object[]{reason, this.generation, this.currentOrder.mode});
      }
   }

   private void expireExpectedResponse() {
      if (this.expectedReason != AutoShopModule.ResponseReason.NONE && System.nanoTime() - this.expectationExpiresAt >= 0L) {
         Night.LOGGER.info("[AutoShop] SILENT_EXPECT_EXPIRE reason={} generation={}", this.expectedReason, this.expectedGeneration);
         this.expectedReason = AutoShopModule.ResponseReason.NONE;
      }
   }

   private void clearSilentState() {
      this.expectedReason = AutoShopModule.ResponseReason.NONE;
      this.expectedGeneration = 0L;
      this.realShopScreenIntercepted = false;
      this.silentSession = false;
   }

   private void resetTransactionWithoutClosingContainer(String reason) {
      Night.LOGGER.warn("[AutoShop] UNEXPECTED_SCREEN FAIL_OPEN_RESET reason={} state={} generation={}", new Object[]{reason, this.state, this.generation});
      this.markAutoFailure();
      this.state = AutoShopModule.State.IDLE;
      this.orderQueue.clear();
      this.currentOrder = null;
      this.quantitySet = false;
      this.ticks = 0;
      this.timeoutTicks = 0;
      this.generation++;
      this.clearSilentState();
   }

   public boolean isRunning() {
      return this.state != AutoShopModule.State.IDLE;
   }

   private void resetAutoControls() {
      for (AutoShopModule.AutoControl control : this.autoControls) {
         control.reset();
      }
   }

   private boolean isTotemAutoOrder() {
      return this.currentOrder != null
         && this.currentOrder.mode == AutoShopModule.ShopMode.Totem
         && this.currentOrder.origin != AutoShopModule.OrderOrigin.MANUAL;
   }

   @SubscribeEvent
   public void onPlayerPop(PlayerPopEvent event) {
      if (event.getPlayer() == mc.player) {
         Player poppedPlayer = event.getPlayer();
         mc.execute(
            () -> {
               if (this.isToggled() && false && mc.player == poppedPlayer) {
                  this.totemPopsSincePurchase++;
                  int threshold = this.totemLostCount.getValue().intValue();
                  Night.LOGGER.info("[AutoShop] TOTEM_POP count={} configured={}", this.totemPopsSincePurchase, threshold);
                  if (this.totemPopsSincePurchase >= threshold) {
                     this.totemPopsSincePurchase = 0;
                     this.enqueuePurchaseOrder(
                        new AutoShopModule.PurchaseOrder(
                           AutoShopModule.ShopMode.Totem, this.totemAmount.getValue().intValue(), AutoShopModule.OrderOrigin.AUTO_PRIMARY
                        )
                     );
                  }
               }
            }
         );
      }
   }

   public boolean usesKitQuota() {
      return false;
   }

   public int kitTarget(Item item) {
      RekitModule rekit = Night.MODULE_MANAGER.getModule(RekitModule.class);
      if (rekit == null) {
         return 0;
      } else {
         String id = BuiltInRegistries.ITEM.getKey(item).toString();
         int count = 0;

         for (RekitModule.KitItem entry : rekit.getActiveKit().values()) {
            if (entry != null && id.equals(entry.id)) {
               count += entry.desiredCount();
            }
         }

         return count;
      }
   }

   public boolean allowsSilentXp() {
      return this.isRunning() && this.silent.getValue() && this.silentSession && mc.gui.screen() == null;
   }

   private long retryDelayNanos() {
      return this.kitRetryDelay.getValue().longValue() * 1000000000L;
   }

   public boolean protectsAutoPurchasedItem(Item item) {
      if (!this.isToggled()) {
         return false;
      } else {
         for (AutoShopModule.ShopMode mode : AutoShopModule.ShopMode.values()) {
            if (itemFor(mode) == item && this.autoEnabled(mode)) {
               return true;
            }
         }

         return false;
      }
   }

   @Override
   public void onEnable() {
      AutoShopLifecycle.begin(this);
      this.resetAutoControls();
      this.clearTotemTracking();
   }

   @Override
   public void onDisable() {
      AutoShopLifecycle.cleanup(this);
   }

   private static Item itemFor(AutoShopModule.ShopMode mode) {
      return switch (mode) {
         case Totem -> Items.TOTEM_OF_UNDYING;
         case Crystal -> Items.END_CRYSTAL;
         case Exp -> Items.EXPERIENCE_BOTTLE;
         case Obsidian -> Items.OBSIDIAN;
         case EnderPearl -> Items.ENDER_PEARL;
      };
   }

   private int stockCount(Item item) {
      if (mc.player == null) {
         return 0;
      } else {
         int count = 0;

         for (int slot = 0; slot < 36; slot++) {
            ItemStack stack = mc.player.getInventory().getItem(slot);
            if (stack.getItem() == item) {
               count += stack.getCount();
            }
         }

         ItemStack var10001 = mc.player.getOffhandItem();
         return count + var10001.getCount() * var10001.getItem().equals(item) * Items.TOTEM_OF_UNDYING.equals(item);
      }
   }

   private int kitCapacity(Item item) {
      int capacity = 0;
      int max = item.getDefaultInstance().getMaxStackSize();
      ItemStack template = item.getDefaultInstance();

      for (int i = 0; i < 36; i++) {
         ItemStack stack = mc.player.getInventory().getItem(i);
         if (stack.isEmpty()) {
            if (i >= 9) {
               capacity += max;
            }
         } else if (ItemStack.isSameItemSameComponents(stack, template)) {
            capacity += Math.max(0, max - stack.getCount());
         }
      }

      return capacity;
   }

   private boolean hasPurchaseSpace(Item item) {
      for (int i = 0; i < 36; i++) {
         ItemStack stack = mc.player.getInventory().getItem(i);
         if (stack.isEmpty() || stack.getItem() == item && stack.getCount() < stack.getMaxStackSize()) {
            return true;
         }
      }

      return false;
   }

   private boolean autoEnabled(AutoShopModule.ShopMode mode) {
      return switch (mode) {
         case Totem -> true;
         case Crystal -> this.crystalBelowThreshold.getValue();
         case Exp -> this.expBelowThreshold.getValue();
         case Obsidian -> this.obsidianBelowThreshold.getValue();
         case EnderPearl -> this.enderPearlBelowThreshold.getValue();
      };
   }

   private int thresholdCount(AutoShopModule.ShopMode mode, Item item) {
      if (mode != AutoShopModule.ShopMode.Totem && this.usesKitQuota()) {
         return KitRestockMath.threshold(this.kitTarget(item), this.kitThresholdPercent.getValue().intValue());
      } else {
         int threshold = switch (mode) {
            case Totem -> this.totemLostCount.getValue().intValue();
            case Crystal -> this.crystalThreshold.getValue().intValue();
            case Exp -> this.expThreshold.getValue().intValue();
            case Obsidian -> this.obsidianThreshold.getValue().intValue();
            case EnderPearl -> this.enderPearlThreshold.getValue().intValue();
         };
         return mode == AutoShopModule.ShopMode.Totem ? threshold : threshold * item.getDefaultInstance().getMaxStackSize();
      }
   }

   private int manualAmount(AutoShopModule.ShopMode mode) {
      return switch (mode) {
         case Totem -> Math.min(
            Math.max(
               this.totemAmount.getValue().intValue(),
               this.thresholdCount(AutoShopModule.ShopMode.Totem, Items.TOTEM_OF_UNDYING) - this.stockCount(Items.TOTEM_OF_UNDYING) + 1
            ),
            10
         );
         case Crystal -> this.crystalStacks.getValue().intValue();
         case Exp -> this.expStacks.getValue().intValue();
         case Obsidian -> this.obsidianStacks.getValue().intValue();
         case EnderPearl -> this.enderPearlStacks.getValue().intValue();
      };
   }

   @SubscribeEvent
   public void onClientDisconnect(ClientDisconnectEvent event) {
      AutoShopLifecycle.disconnected(this);
      this.state = AutoShopModule.State.IDLE;
      this.orderQueue.clear();
      this.currentOrder = null;
      this.lastWorld = null;
      this.lastPlayer = null;
      this.ticks = this.timeoutTicks = 0;
      this.quantitySet = false;
      this.generation++;
      this.clearSilentState();
      this.resetAutoControls();
      this.clearTotemTracking();
   }

   private void finish() {
      Night.LOGGER.info("[AutoShop] FINISH mode={}", this.currentOrder == null ? "unknown" : this.currentOrder.mode);
      this.markAutoServiced();
      this.state = AutoShopModule.State.IDLE;
      this.orderQueue.clear();
      this.currentOrder = null;
      this.generation++;
      this.clearSilentState();
      if (mc.player != null) {
         mc.player.closeContainer();
      }

      Night.CHAT_MANAGER.tagged("Done.", this.getName());
   }

   private void abort(String reason) {
      Night.LOGGER.warn("[AutoShop] ABORT reason={} state={}", reason, this.state);
      this.markAutoFailure();
      this.state = AutoShopModule.State.IDLE;
      this.orderQueue.clear();
      this.currentOrder = null;
      this.generation++;
      this.clearSilentState();
      if (mc.player != null) {
         mc.player.closeContainer();
      }

      Night.CHAT_MANAGER.tagged("Aborted: " + reason, this.getName());
   }

   private void click(int slot) {
      InventoryUtils.click(slot, 0, ContainerInput.PICKUP);
   }

   @Override
   public String getMetaData() {
      return this.currentOrder != null
         ? this.currentOrder.mode.name() + " " + this.currentOrder.remaining + (this.orderQueue.isEmpty() ? "" : " (+" + this.orderQueue.size() + ")")
         : "";
   }

   @SubscribeEvent
   public void onLifecycleTick(TickEvent var1) {
      AutoShopLifecycle.guard(this);
   }

   @SubscribeEvent
   public void onLifecycleDeath(PlayerDeathEvent var1) {
      AutoShopLifecycle.death(this, var1);
   }

   @SubscribeEvent
   public void onPlayerUpdate(PlayerUpdateEvent event) {
      if (!AutoShopLifecycle.guard(this)) {
         if (!GrimV3Inventory.totemTransaction()) {
            if (this.lastWorld != mc.level || this.lastPlayer != mc.player) {
               if (this.lastWorld != null && this.state != AutoShopModule.State.IDLE) {
                  this.abort("Player changed world/session");
               }

               this.lastWorld = mc.level;
               this.lastPlayer = mc.player;
               this.generation++;
               this.clearSilentState();
               this.resetAutoControls();
               this.clearTotemTracking();
            }

            if (mc.player != null && (mc.player.isDeadOrDying() || !mc.player.isAlive() || mc.player.getHealth() <= 0.0F) && this.isTotemAutoOrder()) {
               this.abort("Player dead during automatic Totem order");
               this.clearTotemTracking();
            }

            if (false) {
               this.clearTotemTracking();
            }

            if (this.state == AutoShopModule.State.IDLE && !this.orderQueue.isEmpty() && this.canBeginOrder()) {
               this.currentOrder = this.orderQueue.poll();
               this.beginOrder();
            }

            this.observeTotemStock();
            this.tryStartAutomaticOrder();
            if (this.state != AutoShopModule.State.IDLE) {
               if (mc.player != null && mc.level != null) {
                  this.expireExpectedResponse();
                  if (this.ticks < this.actionDelay.getValue().intValue()) {
                     this.ticks++;
                  } else {
                     this.ticks = 0;
                     Screen currentScreen = mc.gui.screen();
                     boolean screenOpen = currentScreen instanceof AbstractContainerScreen && !(currentScreen instanceof InventoryScreen);
                     if (this.silent.getValue() && this.silentSession) {
                        screenOpen = screenOpen || mc.player.hasContainerOpen();
                     }

                     if (this.state != AutoShopModule.State.WAIT_SHOP && !screenOpen) {
                        this.abort("Shop GUI closed unexpectedly.");
                     } else {
                        switch (this.state) {
                           case WAIT_SHOP:
                              if (screenOpen || this.silent.getValue() && this.realShopScreenIntercepted) {
                                 this.realShopScreenIntercepted = false;
                                 Night.LOGGER
                                    .info(
                                       "[AutoShop] SHOP_ACCEPTED mode={} generation={}",
                                       this.currentOrder == null ? "unknown" : this.currentOrder.mode,
                                       this.generation
                                    );
                                 this.state = AutoShopModule.State.CLICK_ITEM;
                                 this.timeoutTicks = 0;
                              } else {
                                 this.timeoutTicks++;
                                 if (this.timeoutTicks % 20 == 0) {
                                    this.sendShopCommand();
                                 }

                                 if (this.timeoutTicks > 100) {
                                    this.abort("Shop GUI never opened.");
                                 }
                              }
                              break;
                           case CLICK_ITEM:
                              if (this.currentOrder == null) {
                                 this.state = AutoShopModule.State.DECIDE;
                                 return;
                              }
                              int slot = switch (this.currentOrder.mode) {
                                 case Totem -> 13;
                                 case Crystal -> 10;
                                 case Exp -> 16;
                                 case Obsidian -> 9;
                                 case EnderPearl -> 14;
                              };
                              if (this.silent.getValue() && this.silentSession) {
                                 this.armExpectedResponse(AutoShopModule.ResponseReason.ITEM_SELECTION);
                              }

                              Night.LOGGER.info("[AutoShop] ITEM_CLICK mode={} slot={}", this.currentOrder.mode, slot);
                              this.click(slot);
                              this.state = AutoShopModule.State.DECIDE;
                              break;
                           case DECIDE:
                              if (this.currentOrder == null
                                 || this.currentOrder.remaining <= 0
                                 || this.currentOrder.kitTarget > 0 && this.stockCount(itemFor(this.currentOrder.mode)) >= this.currentOrder.kitTarget) {
                                 if (!this.orderQueue.isEmpty()) {
                                    this.markAutoServiced();
                                    this.currentOrder = this.orderQueue.poll();
                                    this.beginOrder();
                                    return;
                                 }

                                 this.finish();
                                 return;
                              }

                              if (this.currentOrder.mode == AutoShopModule.ShopMode.Totem) {
                                 this.state = AutoShopModule.State.CONFIRM;
                              } else if (!this.quantitySet) {
                                 this.state = AutoShopModule.State.SET_11;
                              } else {
                                 this.state = AutoShopModule.State.CONFIRM;
                              }
                              break;
                           case SET_11:
                              int slot = this.currentOrder != null && this.currentOrder.mode == AutoShopModule.ShopMode.EnderPearl ? 15 : 16;
                              if (this.silent.getValue() && this.silentSession) {
                                 this.armExpectedResponse(AutoShopModule.ResponseReason.QUANTITY_SELECTION);
                              }

                              Night.LOGGER
                                 .info("[AutoShop] QUANTITY_CLICK mode={} slot={}", this.currentOrder == null ? "unknown" : this.currentOrder.mode, slot);
                              this.click(slot);
                              this.quantitySet = true;
                              this.state = AutoShopModule.State.CONFIRM;
                              break;
                           case CONFIRM:
                              if (this.currentOrder != null && this.currentOrder.kitTarget > 0) {
                                 Item item = itemFor(this.currentOrder.mode);
                                 int actual = this.stockCount(item);
                                 int effective = Math.max(actual, this.currentOrder.expectedStock);
                                 int pending = Math.max(0, this.currentOrder.expectedStock - actual);
                                 int next = this.currentOrder.quantity << Math.min(2, this.currentOrder.confirmed);
                                 if (this.kitTarget(item) != this.currentOrder.kitTarget
                                    || next > Math.max(0, this.currentOrder.kitTarget + item.getDefaultInstance().getMaxStackSize() / 2 - effective)
                                    || next > Math.max(0, this.kitCapacity(item) - pending)) {
                                    Night.LOGGER
                                       .info(
                                          "[AutoShop] KIT_BOUNDED_STOP mode={} actual={} predicted={} next={} capacity={}",
                                          new Object[]{this.currentOrder.mode, actual, effective, next, this.kitCapacity(item)}
                                       );
                                    this.finish();
                                    return;
                                 }

                                 this.currentOrder.expectedStock = effective + next;
                                 this.currentOrder.confirmed++;
                                 Night.LOGGER
                                    .info(
                                       "[AutoShop] KIT_CONFIRM mode={} quantity={} predicted={} actual={}",
                                       new Object[]{this.currentOrder.mode, next, this.currentOrder.expectedStock, actual}
                                    );
                              }

                              Night.LOGGER
                                 .info(
                                    "[AutoShop] CONFIRM mode={} remaining={}",
                                    this.currentOrder == null ? "unknown" : this.currentOrder.mode,
                                    this.currentOrder == null ? 0 : this.currentOrder.remaining
                                 );
                              this.click(23);
                              if (this.currentOrder != null) {
                                 this.currentOrder.remaining--;
                              }

                              this.state = AutoShopModule.State.DECIDE;
                        }
                     }
                  }
               } else {
                  this.abort("Player left world");
               }
            }
         }
      }
   }

   private void clearTotemTracking() {
      this.totemTrackingInitialized = false;
      this.totemContainerResyncPending = false;
      this.totemZeroFailsafePending = false;
      this.totemZeroFailsafeUsed = false;
      this.totemOrderRecovered = false;
      this.totemEpisodeTriggerReason = "LOSS";
      this.baselineTotems = 0;
      this.previousObservedTotems = 0;
      this.totemAutoControl().reset();
   }

   private void resetTotemBaseline(int stock, String reason) {
      int old = this.baselineTotems;
      this.baselineTotems = stock;
      this.previousObservedTotems = stock;
      this.totemTrackingInitialized = true;
      this.totemContainerResyncPending = false;
      this.totemZeroFailsafePending = false;
      this.totemZeroFailsafeUsed = false;
      this.totemEpisodeTriggerReason = "LOSS";
      AutoShopModule.AutoControl control = this.totemAutoControl();
      control.reset();
      control.wasEnabled = true;
      Night.LOGGER.info("[AutoShop] TOTEM_BASELINE_RESET reason={} old={} new={}", new Object[]{reason, old, stock});
   }

   private boolean isUnrelatedInventorySession() {
      Screen screen = mc.gui.screen();
      boolean ownedShop = this.state != AutoShopModule.State.IDLE && this.currentOrder != null;
      if (screen instanceof InventoryScreen) {
         return true;
      } else if (screen instanceof AbstractContainerScreen) {
         return !ownedShop;
      } else {
         return !mc.player.hasContainerOpen()
            ? false
            : !ownedShop || !this.silent.getValue() || !this.silentSession && this.expectedReason == AutoShopModule.ResponseReason.NONE;
      }
   }

   private void observeTotemStock() {
      AutoShopModule.AutoControl control = this.totemAutoControl();
      if (true) {
         if (mc.player != null
            && mc.level != null
            && mc.getConnection() != null
            && mc.player.isAlive()
            && !mc.player.isDeadOrDying()
            && !(mc.player.getHealth() <= 0.0F)) {
            int stock = this.stockCount(Items.TOTEM_OF_UNDYING);
            if (this.isUnrelatedInventorySession()) {
               this.totemContainerResyncPending = true;
            } else if (this.totemContainerResyncPending) {
               this.resetTotemBaseline(stock, "CONTAINER_RESYNC");
            } else if (!this.totemTrackingInitialized) {
               this.resetTotemBaseline(stock, "ENABLE/SESSION");
               Night.LOGGER.info("[AutoShop] TOTEM_AUTO_ENABLE baseline={}", stock);
            } else if (stock > this.previousObservedTotems) {
               if (this.isTotemAutoOrder()) {
                  this.totemOrderRecovered = true;
               }

               this.resetTotemBaseline(stock, "STOCK_INCREASE");
               Night.LOGGER.info("[AutoShop] TOTEM_AUTO_RECOVER stock={}", stock);
            } else {
               if (stock < this.previousObservedTotems) {
                  if (this.previousObservedTotems > 0 && stock == 0 && this.baselineTotems > 0 && !this.totemZeroFailsafeUsed) {
                     this.totemZeroFailsafePending = true;
                     Night.LOGGER
                        .info(
                           "[AutoShop] TOTEM_ZERO_FAILSAFE baseline={} current=0 configured={}", this.baselineTotems, this.totemLostCount.getValue().intValue()
                        );
                  }

                  int lost = Math.max(0, this.baselineTotems - stock);
                  Night.LOGGER
                     .info(
                        "[AutoShop] TOTEM_LOSS baseline={} current={} lost={} configured={}",
                        new Object[]{this.baselineTotems, stock, lost, this.totemLostCount.getValue().intValue()}
                     );
               }

               this.previousObservedTotems = stock;
            }
         } else {
            if (this.totemTrackingInitialized) {
               this.clearTotemTracking();
            }
         }
      } else {
         if (this.totemTrackingInitialized || control.wasEnabled) {
            Night.LOGGER.info("[AutoShop] TOTEM_AUTO_DISABLE");
            this.clearTotemTracking();
         }
      }
   }

   private void markAutoFailure() {
      if (this.currentOrder != null && this.currentOrder.origin != AutoShopModule.OrderOrigin.MANUAL) {
         if (this.isTotemAutoOrder()) {
            if (false || this.totemOrderRecovered) {
               return;
            }

            if (this.currentOrder.origin == AutoShopModule.OrderOrigin.AUTO_PRIMARY) {
               Night.LOGGER.warn("[AutoShop] TOTEM_AUTO_RETRY cooldownSeconds=5");
            } else {
               Night.LOGGER.warn("[AutoShop] TOTEM_AUTO_RETRY_EXHAUSTED");
            }
         }

         AutoShopModule.AutoControl control = this.autoControls[this.currentOrder.mode.ordinal()];
         if (this.currentOrder.origin == AutoShopModule.OrderOrigin.AUTO_PRIMARY) {
            control.phase = AutoShopModule.AutoPhase.RETRY_COOLDOWN;
            control.retryAtNanos = System.nanoTime() + 5000000000L;
            Night.LOGGER.warn("[AutoShop] AUTO_RETRY_SCHEDULED mode={} cooldownSeconds=5", this.currentOrder.mode);
         } else {
            control.phase = AutoShopModule.AutoPhase.EXHAUSTED;
            Night.LOGGER.warn("[AutoShop] AUTO_RETRY_EXHAUSTED mode={}", this.currentOrder.mode);
         }
      }
   }

   private void markAutoServiced() {
      if (this.currentOrder != null && this.currentOrder.origin != AutoShopModule.OrderOrigin.MANUAL) {
         if (!this.isTotemAutoOrder() || true && !this.totemOrderRecovered) {
            AutoShopModule.AutoControl control = this.autoControls[this.currentOrder.mode.ordinal()];
            control.phase = AutoShopModule.AutoPhase.SERVICED;
            int stock = this.stockCount(itemFor(this.currentOrder.mode));
            control.peakStock = Math.max(control.startStock, stock);
            Night.LOGGER
               .info("[AutoShop] AUTO_SERVICED mode={} observedStock={} startStock={}", new Object[]{this.currentOrder.mode, stock, control.startStock});
         }
      }
   }

   private boolean tryStartAutomaticTotemOrder() {
      if (true
         && this.totemTrackingInitialized
         && !this.totemContainerResyncPending
         && mc.player != null
         && mc.level != null
         && mc.getConnection() != null
         && mc.player.isAlive()
         && !mc.player.isDeadOrDying()
         && !(mc.player.getHealth() <= 0.0F)) {
         AutoShopModule.AutoControl control = this.totemAutoControl();
         if (this.state != AutoShopModule.State.IDLE || !this.orderQueue.isEmpty()) {
            return false;
         } else if (control.phase != AutoShopModule.AutoPhase.READY && control.phase != AutoShopModule.AutoPhase.RETRY_COOLDOWN) {
            return false;
         } else {
            int stock = this.previousObservedTotems;
            int lost = Math.max(0, this.baselineTotems - stock);
            int configuredLoss = this.totemLostCount.getValue().intValue();
            boolean lossTrigger = lost >= configuredLoss;
            boolean zeroTrigger = this.baselineTotems > 0 && stock == 0 && this.totemZeroFailsafePending && !this.totemZeroFailsafeUsed;
            if ((control.phase == AutoShopModule.AutoPhase.RETRY_COOLDOWN || lossTrigger || zeroTrigger) && this.autoStartSafe(Items.TOTEM_OF_UNDYING)) {
               if (control.phase == AutoShopModule.AutoPhase.RETRY_COOLDOWN && System.nanoTime() - control.retryAtNanos < 0L) {
                  return false;
               } else {
                  AutoShopModule.OrderOrigin origin = control.phase == AutoShopModule.AutoPhase.READY
                     ? AutoShopModule.OrderOrigin.AUTO_PRIMARY
                     : AutoShopModule.OrderOrigin.AUTO_RETRY;
                  if (origin == AutoShopModule.OrderOrigin.AUTO_PRIMARY) {
                     control.startStock = stock;
                  }

                  control.phase = origin == AutoShopModule.OrderOrigin.AUTO_PRIMARY
                     ? AutoShopModule.AutoPhase.RUNNING_PRIMARY
                     : AutoShopModule.AutoPhase.RUNNING_RETRY;
                  control.peakStock = Math.max(control.peakStock, stock);
                  this.totemOrderRecovered = false;
                  if (origin == AutoShopModule.OrderOrigin.AUTO_PRIMARY) {
                     this.totemEpisodeTriggerReason = lossTrigger ? "LOSS" : "ZERO_FAILSAFE";
                     if (zeroTrigger && !lossTrigger) {
                        this.totemZeroFailsafePending = false;
                        this.totemZeroFailsafeUsed = true;
                     }
                  }

                  int amount = this.totemAmount.getValue().intValue();
                  Night.LOGGER
                     .info(
                        "[AutoShop] TOTEM_AUTO_TRIGGER reason={} lost={} configured={} amount={} attempt={}",
                        new Object[]{this.totemEpisodeTriggerReason, lost, configuredLoss, amount, origin}
                     );
                  this.enqueuePurchaseOrder(new AutoShopModule.PurchaseOrder(AutoShopModule.ShopMode.Totem, amount, origin));
                  return true;
               }
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   private void tryStartAutomaticOrder() {
      if (mc.player != null && mc.level != null && mc.getConnection() != null) {
         AutoShopModule.ShopMode[] modes = AutoShopModule.ShopMode.values();

         for (AutoShopModule.ShopMode mode : modes) {
            if (mode == AutoShopModule.ShopMode.Totem) {
               if (this.tryStartAutomaticTotemOrder()) {
                  return;
               }
            } else {
               int i = mode.ordinal();
               AutoShopModule.AutoControl control = this.autoControls[i];
               boolean enabled = this.autoEnabled(mode);
               if (!enabled) {
                  control.wasEnabled = false;
               } else {
                  if (!control.wasEnabled) {
                     control.reset();
                     control.wasEnabled = true;
                     Night.LOGGER.info("[AutoShop] AUTO_REARM mode={} reason=TOGGLE_ON", mode);
                  }

                  int stock = this.stockCount(itemFor(mode));
                  int threshold = this.thresholdCount(mode, itemFor(mode));
                  if (control.phase == AutoShopModule.AutoPhase.SERVICED || control.phase == AutoShopModule.AutoPhase.EXHAUSTED) {
                     control.peakStock = Math.max(control.peakStock, stock);
                     if (stock > threshold || control.peakStock > control.startStock && stock < control.peakStock && stock <= threshold) {
                        control.phase = AutoShopModule.AutoPhase.READY;
                        Night.LOGGER.info("[AutoShop] AUTO_REARM mode={} reason={}", mode, stock > threshold ? "ABOVE_THRESHOLD" : "RECOVERY_THEN_CONSUMPTION");
                     }
                  } else if (control.phase == AutoShopModule.AutoPhase.RETRY_COOLDOWN) {
                     if (stock > control.startStock) {
                        control.phase = AutoShopModule.AutoPhase.SERVICED;
                        control.peakStock = stock;
                        Night.LOGGER.info("[AutoShop] AUTO_SERVICED mode={} reason=STOCK_INCREASE_DURING_COOLDOWN", mode);
                     } else if (stock > threshold) {
                        control.phase = AutoShopModule.AutoPhase.READY;
                        Night.LOGGER.info("[AutoShop] AUTO_REARM mode={} reason=ABOVE_THRESHOLD", mode);
                     }
                  }

                  if (this.state == AutoShopModule.State.IDLE
                     && this.orderQueue.isEmpty()
                     && (control.phase == AutoShopModule.AutoPhase.READY || control.phase == AutoShopModule.AutoPhase.RETRY_COOLDOWN)
                     && stock <= threshold
                     && this.autoStartSafe(itemFor(mode))
                     && (control.phase != AutoShopModule.AutoPhase.RETRY_COOLDOWN || System.nanoTime() - control.retryAtNanos >= 0L)) {
                     AutoShopModule.OrderOrigin origin = control.phase == AutoShopModule.AutoPhase.READY
                        ? AutoShopModule.OrderOrigin.AUTO_PRIMARY
                        : AutoShopModule.OrderOrigin.AUTO_RETRY;
                     if (origin == AutoShopModule.OrderOrigin.AUTO_PRIMARY) {
                        control.startStock = stock;
                     }

                     control.phase = origin == AutoShopModule.OrderOrigin.AUTO_PRIMARY
                        ? AutoShopModule.AutoPhase.RUNNING_PRIMARY
                        : AutoShopModule.AutoPhase.RUNNING_RETRY;
                     control.peakStock = Math.max(control.peakStock, stock);
                     int amount = this.manualAmount(mode);
                     Night.LOGGER
                        .info(
                           "[AutoShop] {} mode={} attempt={} stock={} threshold={} amount={}",
                           new Object[]{
                              origin == AutoShopModule.OrderOrigin.AUTO_PRIMARY ? "AUTO_TRIGGER" : "AUTO_RETRY",
                              mode,
                              origin == AutoShopModule.OrderOrigin.AUTO_PRIMARY ? "PRIMARY" : "RETRY",
                              stock,
                              threshold,
                              amount
                           }
                        );
                     this.enqueuePurchaseOrder(new AutoShopModule.PurchaseOrder(mode, amount, origin));
                     return;
                  }
               }
            }
         }
      }
   }

   private boolean autoStartSafe(Item item) {
      if (mc.gui.screen() == null && !mc.player.hasContainerOpen()) {
         for (int slot = 0; slot < 36; slot++) {
            ItemStack stack = mc.player.getInventory().getItem(slot);
            if (stack.isEmpty() || stack.getItem() == item && stack.getCount() < stack.getMaxStackSize()) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private AutoShopModule.AutoControl totemAutoControl() {
      return this.autoControls[AutoShopModule.ShopMode.Totem.ordinal()];
   }

   private static final class AutoControl {
      private AutoShopModule.AutoPhase phase = AutoShopModule.AutoPhase.READY;
      private boolean wasEnabled;
      private int startStock;
      private int peakStock;
      private long retryAtNanos;
      private boolean refilling;

      private void reset() {
         this.phase = AutoShopModule.AutoPhase.READY;
         this.wasEnabled = false;
         this.startStock = 0;
         this.peakStock = 0;
         this.retryAtNanos = 0L;
         this.refilling = false;
      }
   }

   private static enum AutoPhase {
      READY,
      RUNNING_PRIMARY,
      RETRY_COOLDOWN,
      RUNNING_RETRY,
      SERVICED,
      EXHAUSTED;
   }

   private static enum OrderOrigin {
      MANUAL,
      AUTO_PRIMARY,
      AUTO_RETRY;
   }

   public static class PurchaseOrder {
      public final AutoShopModule.ShopMode mode;
      public int remaining;
      private final AutoShopModule.OrderOrigin origin;
      private int kitTarget;
      private int quantity = 1;
      private int confirmed;
      private int expectedStock;

      public PurchaseOrder(AutoShopModule.ShopMode mode, int remaining) {
         this(mode, remaining, AutoShopModule.OrderOrigin.MANUAL);
      }

      private PurchaseOrder(AutoShopModule.ShopMode mode, int remaining, AutoShopModule.OrderOrigin origin) {
         this.mode = mode;
         this.remaining = remaining;
         this.origin = origin;
      }
   }

   private static enum ResponseReason {
      NONE,
      SHOP_COMMAND,
      ITEM_SELECTION,
      QUANTITY_SELECTION;
   }

   public static enum ScreenDecision {
      PASS,
      SUPPRESS_EXPECTED,
      FAIL_OPEN_UNEXPECTED;
   }

   public static enum ShopMode {
      Totem,
      Crystal,
      Exp,
      Obsidian,
      EnderPearl;
   }

   private static enum State {
      IDLE,
      WAIT_SHOP,
      CLICK_ITEM,
      DECIDE,
      SET_11,
      CONFIRM;
   }
}
